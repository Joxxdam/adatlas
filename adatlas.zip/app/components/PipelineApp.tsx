"use client";

import { useState } from "react";
import type { BrandSource, CollectedAdImage, GeneratedAd } from "../lib/pipeline/types";

type Props = {
  initialBrands: BrandSource[];
  initialImages: CollectedAdImage[];
  initialGenerated: GeneratedAd[];
};

type Status = { type: "idle" | "loading" | "success" | "error"; message: string };

export function PipelineApp({ initialBrands, initialGenerated, initialImages }: Props) {
  const [brands, setBrands] = useState(initialBrands);
  const [images, setImages] = useState(initialImages);
  const [generated, setGenerated] = useState(initialGenerated);
  const [selectedBrandId, setSelectedBrandId] = useState(initialBrands[0]?.id ?? "");
  const [selectedImageIds, setSelectedImageIds] = useState<string[]>([]);
  const [productUrl, setProductUrl] = useState("");
  const [status, setStatus] = useState<Status>({ type: "idle", message: "브랜드를 선택하고 광고 이미지를 수집하세요." });

  const selectedBrand = brands.find((brand) => brand.id === selectedBrandId) ?? brands[0];
  const activeBrands = brands.filter((brand) => brand.enabled);

  async function reload() {
    const response = await fetch("/api/images");
    const result = await response.json();
    setBrands(result.brands ?? []);
    setImages(result.images ?? []);
    setGenerated(result.generated ?? []);
  }

  async function saveBrands(next: BrandSource[]) {
    setBrands(next);
    await fetch("/api/images", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ brands: next }),
    });
  }

  async function crawlBrand(platform: "Meta" | "TikTok", brand = selectedBrand) {
    if (!brand) return;
    const endpoint = platform === "Meta" ? "/api/crawl/meta" : "/api/crawl/tiktok";
    const payload =
      platform === "Meta"
        ? { brandName: brand.brandName, metaLibraryUrl: brand.metaUrl, limit: 10 }
        : { brandName: brand.brandName, tiktokUrl: brand.tiktokUrl, limit: 10 };

    setStatus({ type: "loading", message: `${brand.brandName} ${platform} 이미지를 수집 중입니다.` });
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      setStatus({ type: "error", message: result.error ?? `${platform} 수집 실패` });
      return;
    }
    await reload();
    setStatus({ type: "success", message: `${brand.brandName} ${platform} 이미지 ${result.count}개 수집 완료` });
  }

  async function crawlToday() {
    for (const brand of activeBrands.slice(0, 100)) {
      await crawlBrand("Meta", brand);
      if (brand.tiktokUrl) await crawlBrand("TikTok", brand);
    }
  }

  async function analyzeImage(imageId?: string) {
    setStatus({ type: "loading", message: "이미지를 분석 중입니다." });
    const response = await fetch("/api/analyze/image", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ imageId }),
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      setStatus({ type: "error", message: result.error ?? "이미지 분석 실패" });
      return;
    }
    setImages(result.images ?? []);
    setStatus({ type: "success", message: `분석 완료 이미지 ${result.analyzed}개` });
  }

  async function generateAd() {
    setStatus({ type: "loading", message: "레퍼런스 스타일을 참고해 1200x1200 PNG를 생성 중입니다." });
    const response = await fetch("/api/generate/ad-image", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productUrl, referenceImageIds: selectedImageIds }),
    });
    const result = await response.json();
    if (!response.ok || !result.success) {
      setStatus({ type: "error", message: result.error ?? "광고 이미지 생성 실패" });
      return;
    }
    await reload();
    setStatus({ type: "success", message: "1200x1200 PNG 생성 완료" });
  }

  function toggleReference(id: string) {
    setSelectedImageIds((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id].slice(-3),
    );
  }

  return (
    <main className="pipeline-shell">
      <header className="pipeline-header">
        <div>
          <p className="eyebrow">AdAtlas Pipeline MVP</p>
          <h1>광고 이미지 수집·분석·생성 파이프라인</h1>
        </div>
        <button onClick={crawlToday} type="button">오늘 전체 수집 실행</button>
      </header>

      <div className={`pipeline-status ${status.type}`}>{status.message}</div>

      <section className="pipeline-section">
        <div className="section-head">
          <h2>1. 브랜드 소스</h2>
          <span>{brands.length}개 브랜드</span>
        </div>
        <div className="brand-source-grid">
          {brands.slice(0, 100).map((brand, index) => (
            <article className={selectedBrandId === brand.id ? "active" : ""} key={brand.id}>
              <button onClick={() => setSelectedBrandId(brand.id)} type="button">{brand.brandName}</button>
              <input value={brand.category} onChange={(event) => {
                const next = [...brands];
                next[index] = { ...brand, category: event.target.value };
                setBrands(next);
              }} />
              <input value={brand.metaUrl} onChange={(event) => {
                const next = [...brands];
                next[index] = { ...brand, metaUrl: event.target.value };
                setBrands(next);
              }} />
              <input value={brand.tiktokUrl} onChange={(event) => {
                const next = [...brands];
                next[index] = { ...brand, tiktokUrl: event.target.value };
                setBrands(next);
              }} />
              <label><input checked={brand.enabled} onChange={(event) => {
                const next = [...brands];
                next[index] = { ...brand, enabled: event.target.checked };
                setBrands(next);
              }} type="checkbox" /> 수집 ON</label>
              <div>
                <button onClick={() => crawlBrand("Meta", brand)} type="button">Meta 테스트</button>
                <button onClick={() => crawlBrand("TikTok", brand)} type="button">TikTok 테스트</button>
              </div>
            </article>
          ))}
        </div>
        <button onClick={() => saveBrands(brands)} type="button">브랜드 소스 저장</button>
      </section>

      <section className="pipeline-section">
        <div className="section-head">
          <h2>2. 이미지 수집함</h2>
          <span>{images.length}개 이미지</span>
        </div>
        <ImageGrid images={images} onSelect={toggleReference} selectedIds={selectedImageIds} />
      </section>

      <section className="pipeline-section">
        <div className="section-head">
          <h2>3. 이미지 분석함</h2>
          <button onClick={() => analyzeImage()} type="button">전체 mock 분석 실행</button>
        </div>
        <div className="analysis-grid">
          {images.filter((image) => image.analysis).map((image) => (
            <article key={image.id}>
              <img alt={`${image.brandName} 분석 이미지`} src={image.localImagePath} />
              <div>
                <strong>{image.brandName}</strong>
                <p>{image.analysis?.imageText}</p>
                <span>{image.analysis?.hookType} / {image.analysis?.layoutPattern}</span>
                <span>{image.analysis?.appealPoint}</span>
                <span>{image.analysis?.designTone}</span>
                <b>{image.analysis?.recommendedUse}</b>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="pipeline-section generator-section">
        <div className="section-head">
          <h2>4. 광고 생성</h2>
          <span>레퍼런스 {selectedImageIds.length}/3개 선택</span>
        </div>
        <div className="generator-layout">
          <div className="generator-controls">
            <input placeholder="상품 웹사이트 URL" value={productUrl} onChange={(event) => setProductUrl(event.target.value)} />
            <button onClick={generateAd} type="button">1200x1200 광고 이미지 생성</button>
            <p>선택한 레퍼런스의 디자인 톤, 구도, 후킹 구조를 참고하는 API 경계입니다. 현재는 mock PNG를 생성하고, 이후 OpenAI 이미지 생성으로 교체 가능합니다.</p>
          </div>
          <div className="generated-preview">
            {generated[0] ? (
              <>
                <img alt="생성 광고" src={generated[0].localImagePath} />
                <a download href={generated[0].localImagePath}>PNG 다운로드</a>
              </>
            ) : (
              <span>생성된 광고 이미지가 여기에 표시됩니다.</span>
            )}
          </div>
        </div>
      </section>
    </main>
  );
}

function ImageGrid({
  images,
  onSelect,
  selectedIds,
}: {
  images: CollectedAdImage[];
  onSelect: (id: string) => void;
  selectedIds: string[];
}) {
  return (
    <div className="image-moodboard">
      {images.map((image) => (
        <article className={selectedIds.includes(image.id) ? "selected" : ""} key={image.id} onClick={() => onSelect(image.id)}>
          <img alt={`${image.brandName} 광고 이미지`} src={image.localImagePath} />
          <div>
            <strong>{image.brandName}</strong>
            <span>{image.sourcePlatform}</span>
            <span>{new Date(image.collectedAt).toLocaleDateString("ko-KR")}</span>
            {image.originalAdUrl ? <a href={image.originalAdUrl} onClick={(event) => event.stopPropagation()} target="_blank">원본 링크</a> : null}
          </div>
        </article>
      ))}
    </div>
  );
}
