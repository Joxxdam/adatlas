import { NextResponse } from "next/server";
import { readBrandSources, readCollectedImages, readGeneratedAds, saveBrandSources } from "../../lib/pipeline/store";

export const runtime = "nodejs";

export async function GET() {
  const [brands, images, generated] = await Promise.all([readBrandSources(), readCollectedImages(), readGeneratedAds()]);
  return NextResponse.json({ brands, images, generated });
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  if (Array.isArray(body.brands)) {
    await saveBrandSources(body.brands);
    return NextResponse.json({ success: true, brands: body.brands });
  }
  return NextResponse.json({ success: false, error: "brands 배열이 필요합니다." }, { status: 400 });
}
