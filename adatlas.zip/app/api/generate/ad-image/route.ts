import { promises as fs } from "fs";
import path from "path";
import sharp from "sharp";
import { NextResponse } from "next/server";
import { extractProductInfo } from "../../../lib/mvp/productExtractor";
import { addGeneratedAd, readCollectedImages } from "../../../lib/pipeline/store";
import { GeneratedAd } from "../../../lib/pipeline/types";

export const runtime = "nodejs";
export const maxDuration = 120;

function escapeXml(value: string) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function svgTemplate(productName: string, price: string, description: string, tone: string) {
  return `
  <svg width="1200" height="1200" xmlns="http://www.w3.org/2000/svg">
    <rect width="1200" height="1200" fill="#f8fafc"/>
    <rect x="60" y="60" width="1080" height="1080" rx="34" fill="#ffffff" stroke="#e5e7eb" stroke-width="4"/>
    <rect x="60" y="60" width="1080" height="190" rx="34" fill="#0f766e"/>
    <text x="110" y="155" font-size="54" font-family="Arial" font-weight="800" fill="#ffffff">${escapeXml(tone)}</text>
    <text x="110" y="390" font-size="76" font-family="Arial" font-weight="900" fill="#111827">${escapeXml(productName.slice(0, 22))}</text>
    <text x="110" y="485" font-size="46" font-family="Arial" font-weight="800" fill="#0f766e">${escapeXml(price || "특별 혜택 확인")}</text>
    <foreignObject x="110" y="560" width="760" height="230">
      <div xmlns="http://www.w3.org/1999/xhtml" style="font-family:Arial;font-size:34px;line-height:1.35;color:#374151;font-weight:600;">${escapeXml(description)}</div>
    </foreignObject>
    <rect x="110" y="950" width="360" height="96" rx="48" fill="#111827"/>
    <text x="177" y="1012" font-size="34" font-family="Arial" font-weight="900" fill="#ffffff">지금 확인하기</text>
    <circle cx="950" cy="745" r="150" fill="#dbeafe"/>
    <circle cx="1018" cy="690" r="96" fill="#ccfbf1"/>
    <text x="820" y="765" font-size="30" font-family="Arial" font-weight="800" fill="#0f766e">REFERENCE</text>
  </svg>`;
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const productUrl = String(body.productUrl ?? body.websiteUrl ?? "").trim();
    const referenceImageIds = Array.isArray(body.referenceImageIds) ? body.referenceImageIds.map(String).slice(0, 3) : [];

    if (!productUrl) {
      return NextResponse.json({ success: false, error: "상품 웹사이트 URL이 필요합니다." }, { status: 400 });
    }

    const [product, images] = await Promise.all([extractProductInfo(productUrl), readCollectedImages()]);
    const references = images.filter((image) => referenceImageIds.includes(image.id)).slice(0, 3);
    const tone = references[0]?.analysis?.designTone || "프리미엄 레퍼런스";
    const id = `ad-${Date.now()}`;
    const dir = path.join(process.cwd(), "public", "generated-ads");
    await fs.mkdir(dir, { recursive: true });
    const fileName = `${id}.png`;
    const outputPath = path.join(dir, fileName);

    await sharp(Buffer.from(svgTemplate(product.productName, product.price, product.description, tone)))
      .png()
      .resize(1200, 1200)
      .toFile(outputPath);

    const generated: GeneratedAd = {
      id,
      productUrl,
      productName: product.productName,
      price: product.price,
      description: product.description,
      referenceImageIds,
      localImagePath: `/generated-ads/${fileName}`,
      createdAt: new Date().toISOString(),
    };
    await addGeneratedAd(generated);

    return NextResponse.json({ success: true, generated, product, references });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "광고 이미지 생성 실패" },
      { status: 500 },
    );
  }
}
