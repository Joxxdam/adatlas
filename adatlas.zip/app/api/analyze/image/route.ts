import { NextResponse } from "next/server";
import { readCollectedImages, saveCollectedImages } from "../../../lib/pipeline/store";
import { AdImageAnalysis } from "../../../lib/pipeline/types";

export const runtime = "nodejs";

function mockAnalyze(brandName: string): AdImageAnalysis {
  const lower = brandName.toLowerCase();
  return {
    imageText: brandName,
    hookType: /sale|특가|할인|쿠폰/i.test(lower) ? "가격소구" : "UGC",
    appealPoint: /beauty|source|olive|뷰티/i.test(lower) ? "시원함/신상" : "고급감/편안함",
    layoutPattern: "상단후킹/중앙상품/하단CTA",
    designTone: "프리미엄/미니멀",
    ctaText: "지금 확인하기",
    recommendedUse: "상품 대표 이미지와 짧은 혜택 문구를 결합한 1200x1200 정방형 광고에 활용",
    analyzedAt: new Date().toISOString(),
  };
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const imageId = body.imageId ? String(body.imageId) : "";
  const images = await readCollectedImages();
  const next = images.map((image) => {
    if (imageId && image.id !== imageId) return image;
    return { ...image, analysis: mockAnalyze(image.brandName) };
  });
  await saveCollectedImages(next);
  return NextResponse.json({ success: true, images: next, analyzed: next.filter((image) => image.analysis).length });
}
