import { chromium, type Locator } from "playwright";
import { NextResponse } from "next/server";
import { downloadImageToPublic, stableId } from "../../../lib/pipeline/files";
import { mergeCollectedImages } from "../../../lib/pipeline/store";
import { CollectedAdImage } from "../../../lib/pipeline/types";

export const runtime = "nodejs";
export const maxDuration = 120;

async function attr(locator: Locator, name: string) {
  try {
    return (await locator.getAttribute(name, { timeout: 800 })) ?? "";
  } catch {
    return "";
  }
}

export async function POST(request: Request) {
  let browser;
  try {
    const body = await request.json().catch(() => ({}));
    const brandName = String(body.brandName ?? "").trim();
    const tiktokUrl = String(body.tiktokUrl ?? "https://ads.tiktok.com/business/creativecenter/inspiration/topads/pc/en").trim();
    const limit = Math.min(Number(body.limit ?? 10), 10);

    if (!brandName) {
      return NextResponse.json({ success: false, error: "brandName이 필요합니다." }, { status: 400 });
    }

    browser = await chromium.launch({ headless: process.env.TIKTOK_CRAWLER_HEADLESS !== "false" });
    const page = await browser.newPage({ viewport: { width: 1440, height: 1200 }, locale: "ko-KR" });
    await page.goto(tiktokUrl, { waitUntil: "domcontentloaded", timeout: 60_000 });
    await page.waitForTimeout(2500);

    const search = page.locator("input").first();
    if (await search.count()) {
      await search.fill(brandName).catch(() => undefined);
      await search.press("Enter").catch(() => undefined);
      await page.waitForTimeout(2500);
    }

    for (let i = 0; i < 5; i += 1) {
      await page.mouse.wheel(0, 1600);
      await page.waitForTimeout(700);
    }

    const imgs = page.locator("img");
    const count = await imgs.count();
    const items: CollectedAdImage[] = [];

    for (let i = 0; i < count && items.length < limit; i += 1) {
      const imageUrl = await attr(imgs.nth(i), "src");
      if (!imageUrl || imageUrl.startsWith("data:") || /logo|avatar|icon/i.test(imageUrl)) continue;
      try {
        const id = stableId(`${brandName}:tiktok:${imageUrl}`);
        const localImagePath = await downloadImageToPublic(imageUrl, id);
        items.push({
          id,
          brandName,
          sourcePlatform: "TikTok",
          imageUrl,
          localImagePath,
          originalAdUrl: tiktokUrl,
          collectedAt: new Date().toISOString(),
        });
      } catch {
        // Skip failed image downloads.
      }
    }

    await mergeCollectedImages(items);
    return NextResponse.json({ success: true, brandName, count: items.length, items });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "TikTok 수집 실패" },
      { status: 500 },
    );
  } finally {
    await browser?.close().catch(() => undefined);
  }
}
