import { NextResponse } from "next/server";
import { crawlMetaAdLibrary } from "../../../lib/meta-crawler/crawlMetaAdLibrary";
import { downloadImageToPublic, stableId } from "../../../lib/pipeline/files";
import { mergeCollectedImages } from "../../../lib/pipeline/store";
import { CollectedAdImage } from "../../../lib/pipeline/types";

export const runtime = "nodejs";
export const maxDuration = 120;

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const brandName = String(body.brandName ?? "").trim();
    const metaLibraryUrl = String(body.metaLibraryUrl ?? "").trim();
    const limit = body.limit ? Number(body.limit) : 20;

    const result = await crawlMetaAdLibrary({ brandName, metaLibraryUrl, limit });
    const items: CollectedAdImage[] = [];

    for (const ad of result.ads) {
      const imageUrl = ad.imageUrl || ad.videoThumbnailUrl || "";
      if (!imageUrl) continue;
      try {
        const originalAdUrl = ad.adSnapshotUrl || ad.landingUrl || "";
        const id = stableId(`${brandName}:meta:${originalAdUrl || imageUrl}`);
        const localImagePath = await downloadImageToPublic(imageUrl, id);
        items.push({
          id,
          brandName,
          sourcePlatform: "Meta",
          imageUrl,
          localImagePath,
          originalAdUrl,
          collectedAt: ad.crawledAt,
        });
      } catch {
        // Keep crawling even if a single image cannot be downloaded.
      }
    }

    await mergeCollectedImages(items);

    return NextResponse.json({
      success: true,
      brandName,
      count: items.length,
      items,
      warnings: result.warnings,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Meta Ad Library crawl failed.",
      },
      { status: 500 },
    );
  }
}
