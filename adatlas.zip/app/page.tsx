import { PipelineApp } from "./components/PipelineApp";
import { readBrandSources, readCollectedImages, readGeneratedAds } from "./lib/pipeline/store";

export const dynamic = "force-dynamic";

export default async function Home() {
  const [brands, images, generated] = await Promise.all([
    readBrandSources(),
    readCollectedImages(),
    readGeneratedAds(),
  ]);

  return <PipelineApp initialBrands={brands} initialGenerated={generated} initialImages={images} />;
}
