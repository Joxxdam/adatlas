import { promises as fs } from "fs";
import path from "path";

export function stableId(value: string) {
  return Buffer.from(value).toString("base64url").slice(0, 28);
}

export async function downloadImageToPublic(imageUrl: string, id: string) {
  const response = await fetch(imageUrl);
  if (!response.ok) {
    throw new Error(`이미지 다운로드 실패: ${response.status}`);
  }

  const contentType = response.headers.get("content-type") ?? "";
  const ext = contentType.includes("png") ? "png" : contentType.includes("webp") ? "webp" : "jpg";
  const dir = path.join(process.cwd(), "public", "collected-images");
  await fs.mkdir(dir, { recursive: true });
  const fileName = `${id}.${ext}`;
  await fs.writeFile(path.join(dir, fileName), Buffer.from(await response.arrayBuffer()));
  return `/collected-images/${fileName}`;
}
