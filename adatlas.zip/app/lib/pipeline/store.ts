import { promises as fs } from "fs";
import path from "path";
import { BrandSource, CollectedAdImage, GeneratedAd } from "./types";
import { WatchlistBrand } from "../watchlist/types";

const dataDir = path.join(process.cwd(), "data");
const watchlistPath = path.join(dataDir, "brand-watchlist.json");
const brandsPath = path.join(dataDir, "pipeline-brands.json");
const imagesPath = path.join(dataDir, "collected-ad-images.json");
const generatedPath = path.join(dataDir, "generated-ad-images.json");

async function ensureFile(filePath: string, fallback: unknown) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  try {
    await fs.access(filePath);
  } catch {
    await fs.writeFile(filePath, `${JSON.stringify(fallback, null, 2)}\n`, "utf8");
  }
}

function slug(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9가-힣]+/g, "-").replace(/(^-|-$)/g, "");
}

export async function readBrandSources(): Promise<BrandSource[]> {
  try {
    await fs.access(brandsPath);
  } catch {
    const raw = await fs.readFile(watchlistPath, "utf8").catch(() => "[]");
    const watchlist = JSON.parse(raw) as WatchlistBrand[];
    const seeded = watchlist.slice(0, 100).map((brand) => ({
      id: slug(brand.brand),
      brandName: brand.brand,
      category: brand.category,
      metaUrl: brand.urls.meta ?? "",
      tiktokUrl: brand.urls.tiktok ?? "",
      enabled: brand.enabled,
    }));
    await ensureFile(brandsPath, seeded);
  }
  return JSON.parse(await fs.readFile(brandsPath, "utf8")) as BrandSource[];
}

export async function saveBrandSources(brands: BrandSource[]) {
  await ensureFile(brandsPath, []);
  await fs.writeFile(brandsPath, `${JSON.stringify(brands, null, 2)}\n`, "utf8");
}

export async function readCollectedImages(): Promise<CollectedAdImage[]> {
  await ensureFile(imagesPath, []);
  return JSON.parse(await fs.readFile(imagesPath, "utf8")) as CollectedAdImage[];
}

export async function saveCollectedImages(images: CollectedAdImage[]) {
  await ensureFile(imagesPath, []);
  await fs.writeFile(imagesPath, `${JSON.stringify(images, null, 2)}\n`, "utf8");
}

export async function mergeCollectedImages(items: CollectedAdImage[]) {
  const existing = await readCollectedImages();
  const keyOf = (item: CollectedAdImage) => item.originalAdUrl || item.imageUrl;
  const byKey = new Map(existing.map((item) => [keyOf(item), item]));
  let added = 0;

  for (const item of items) {
    const key = keyOf(item);
    if (!byKey.has(key)) added += 1;
    byKey.set(key, { ...byKey.get(key), ...item });
  }

  const images = [...byKey.values()].sort((a, b) => b.collectedAt.localeCompare(a.collectedAt));
  await saveCollectedImages(images);
  return { added, total: images.length, images };
}

export async function readGeneratedAds(): Promise<GeneratedAd[]> {
  await ensureFile(generatedPath, []);
  return JSON.parse(await fs.readFile(generatedPath, "utf8")) as GeneratedAd[];
}

export async function addGeneratedAd(item: GeneratedAd) {
  const existing = await readGeneratedAds();
  const next = [item, ...existing];
  await fs.writeFile(generatedPath, `${JSON.stringify(next, null, 2)}\n`, "utf8");
  return item;
}
