export type BrandSource = {
  id: string;
  brandName: string;
  category: string;
  metaUrl: string;
  tiktokUrl: string;
  enabled: boolean;
};

export type CollectedAdImage = {
  id: string;
  brandName: string;
  category?: string;
  sourcePlatform: "Meta" | "TikTok";
  imageUrl: string;
  localImagePath: string;
  originalAdUrl?: string;
  collectedAt: string;
  analysis?: AdImageAnalysis;
};

export type AdImageAnalysis = {
  imageText: string;
  hookType: "문제제기" | "가격소구" | "후기형" | "UGC" | "시즌기획" | "비포애프터";
  appealPoint: string;
  layoutPattern: string;
  designTone: string;
  ctaText: string;
  recommendedUse: string;
  analyzedAt: string;
};

export type GeneratedAd = {
  id: string;
  productUrl: string;
  productName: string;
  price: string;
  description: string;
  referenceImageIds: string[];
  localImagePath: string;
  createdAt: string;
};
